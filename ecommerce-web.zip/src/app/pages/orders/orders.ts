import {
  Component,
  OnInit,
  OnDestroy,
  ChangeDetectorRef
} from '@angular/core';

import {
  Router,
  NavigationEnd
} from '@angular/router';

import { filter } from 'rxjs/operators';

import { CommonModule } from '@angular/common';
import { OrderService } from '../../services/order.service';
import { ToastrService } from 'ngx-toastr';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
@Component({
  selector: 'app-orders',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './orders.html',
  styleUrl: './orders.css'
})
export class Orders
  implements OnInit, OnDestroy {

  orders: any[] = [];
  private refreshInterval: any;

constructor(
  private orderService: OrderService,
  private toastr: ToastrService,
  private router: Router,
  private cdr: ChangeDetectorRef
) {

  this.router.events
    .pipe(
      filter(event => event instanceof NavigationEnd)
    )
    .subscribe(() => {

      if (this.router.url === '/orders') {

        this.loadOrders();

      }

    });

}

  ngOnInit(): void {

    const token =
      localStorage.getItem('token');

    if (token) {
      this.loadOrders();
    }
  }

 loadOrders(): void {

  this.orderService
    .getMyOrders()
    .subscribe({

      next: (res: any) => {

        console.log('Orders:', res);

        this.orders = [...res];
        this.cdr.detectChanges();

      },

      error: (err) => {

        console.log(err);

      }

    });

}

  cancelOrder(id: number): void {

    this.orderService
      .cancelOrder(id)
      .subscribe({

        next: () => {

          this.toastr.success(
            'Order cancelled successfully'
          );

          this.loadOrders();
        },

        error: (err) => {

          console.log(err);

          this.toastr.error(
            err.error
          );
        }
      });
  }

  ngOnDestroy(): void {

    if (this.refreshInterval) {
      clearInterval(
        this.refreshInterval
      );
    }
  }

  downloadInvoice(order: any) {

  const doc = new jsPDF();

  doc.setFontSize(18);
  doc.text('INVOICE', 14, 20);

  doc.setFontSize(12);
  doc.text(`Order ID: ${order.orderID}`, 14, 35);
  doc.text(`Date: ${order.orderDate}`, 14, 45);
  doc.text(`Status: ${order.status}`, 14, 55);

  const rows = order.orderDetails.map((x: any) => [
    x.productName,
    x.quantity,
    x.price
  ]);

  autoTable(doc, {
    head: [['Product', 'Qty', 'Price']],
    body: rows,
    startY: 65
  });

doc.text(
  `Total Amount: Rs. ${order.totalAmount}`,
  14,
  120
);

  doc.save(`Invoice_${order.orderID}.pdf`);
}

}