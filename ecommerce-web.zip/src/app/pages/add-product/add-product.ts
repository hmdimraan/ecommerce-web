import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-add-product',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './add-product.html',
  styleUrl: './add-product.css'
})
export class AddProduct {

  api = environment.apiUrl;

  product: any = {
    productName: '',
    price: 0,
    stock: 0,
    categoryID: 1
  };

  imageFile: File | null = null;

  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  onFileSelected(event: any) {

    this.imageFile =
      event.target.files[0];
  }

  addProduct() {

    const formData =
      new FormData();

    formData.append(
      'productName',
      this.product.productName
    );

    formData.append(
      'price',
      this.product.price
    );

    formData.append(
      'stock',
      this.product.stock
    );

    formData.append(
      'categoryID',
      this.product.categoryID
    );

    if (this.imageFile) {

      formData.append(
        'image',
        this.imageFile
      );
    }

    this.http
      .post(
        `${this.api}/products`,
        formData
      )
      .subscribe(() => {

        this.router.navigate(
          ['/admin-products']
        );
      });
  }
}