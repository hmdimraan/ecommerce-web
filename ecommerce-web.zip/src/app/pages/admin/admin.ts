import {
  Component,
  OnInit,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './admin.html',
  styleUrl: './admin.css'
})
export class Admin implements OnInit {

  api = environment.apiUrl;

  orders: any[] = [];
  selectedStatus = '';

  constructor(
    private http: HttpClient,
    private toastr: ToastrService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {

    this.loadOrders();

  }

  loadOrders(): void {

    this.http
      .get<any[]>(`${this.api}/orders/all`)
      .subscribe({

        next: (res) => {

          this.orders = res;

          this.cdr.detectChanges();

        },

        error: (err) => {

          console.log(err);

          this.toastr.error('Failed to load orders');

        }

      });

  }

  updateStatus(
    id: number,
    status: string
  ): void {

    this.http
      .put(
        `${this.api}/orders/${id}/status?status=${status}`,
        {}
      )
      .subscribe({

        next: () => {

          this.toastr.success('Status Updated');

          this.loadOrders();

        },

        error: (err) => {

          console.log(err);

        }

      });

  }

  get filteredOrders() {

    if (!this.selectedStatus) {

      return this.orders;

    }

    return this.orders.filter(

      o => o.status === this.selectedStatus

    );

  }

}